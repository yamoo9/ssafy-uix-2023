import generateTheme from './utils/generateTheme.mjs';
import print from './utils/print.mjs';

generateTheme();
print();
