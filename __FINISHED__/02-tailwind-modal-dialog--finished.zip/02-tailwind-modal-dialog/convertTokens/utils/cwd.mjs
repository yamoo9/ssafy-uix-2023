import { cwd } from 'node:process';

const ROOT_DIR = cwd();

export default ROOT_DIR;
